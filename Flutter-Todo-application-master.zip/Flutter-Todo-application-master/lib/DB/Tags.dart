class Tags{
  static final int TODO_TASK = 0;
  static final int DOING_TASK = 1;
  static final int DONE_TASK = 2;
}